#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include <event2/event.h>
#include <event2/bufferevent.h>
#include <event2/buffer.h>
#include <event2/util.h>

#include "ikcp.h"

#define BUFFER_SIZE 8092
#define PACKET_SIZE 1400
#define FILENAME "/tmp/filename2"

/* get system time */
static inline void itimeofday(long *sec, long *usec)
{
    #if defined(__unix)
    struct timeval time;
    gettimeofday(&time, NULL);
    if (sec) *sec = time.tv_sec;
    if (usec) *usec = time.tv_usec;
    #else
    static long mode = 0, addsec = 0;
    BOOL retval;
    static IINT64 freq = 1;
    IINT64 qpc;
    if (mode == 0) {
        retval = QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
        freq = (freq == 0)? 1 : freq;
        retval = QueryPerformanceCounter((LARGE_INTEGER*)&qpc);
        addsec = (long)time(NULL);
        addsec = addsec - (long)((qpc / freq) & 0x7fffffff);
        mode = 1;
    }
    retval = QueryPerformanceCounter((LARGE_INTEGER*)&qpc);
    retval = retval * 2;
    if (sec) *sec = (long)(qpc / freq) + addsec;
    if (usec) *usec = (long)((qpc % freq) * 1000000 / freq);
    #endif
}

/* get clock in millisecond 64 */
static inline IINT64 iclock64(void)
{
    long s, u;
    IINT64 value;
    itimeofday(&s, &u);
    value = ((IINT64)s) * 1000 + (u / 1000);
    return value;
}

static inline IUINT32 iclock()
{
    return (IUINT32)(iclock64() & 0xfffffffful);
}

typedef struct {
    int sockfd;
    socklen_t addr_len;
    struct sockaddr_in addr;
    ikcpcb *kcp;
    struct event_base *base;
    struct bufferevent* bev;
    struct evbuffer* inputbuf;
    struct evbuffer* outputbuf;
    int total;
    int net_total;
} Handle;

Handle handle;

// KCP回调函数，用于处理接收到的数据
int kcp_output(const char *buf, int len, ikcpcb *kcp, void *user) {
    Handle *handle = (Handle *)user;
    evbuffer_add(handle->outputbuf, buf, len);
    fprintf(stderr, "kcp output callback %d buffering %ld\n", len, evbuffer_get_length(handle->outputbuf));
    return 0;
}

void write_cb(struct bufferevent* bev, void* ctx)
{
    Handle *handle = (Handle *)ctx;
    bufferevent_flush(handle->bev, EV_WRITE, BEV_FLUSH);
    fprintf(stderr, "write callback left %lu \n",  evbuffer_get_length(handle->outputbuf));
}

void read_cb(struct bufferevent* bev, void* ctx)
{
    Handle * handle = (Handle *)ctx;
    size_t len = evbuffer_get_length(handle->inputbuf);

    // 从输入缓冲区中读取数据
    char buffer[PACKET_SIZE];
    size_t readed = 0;
    while ((readed = evbuffer_remove(handle->inputbuf, buffer, PACKET_SIZE)) > 0)
    {
        int input = ikcp_input(handle->kcp, buffer, readed);
        handle->net_total += readed;
        fprintf(stderr, "net read %ld total %d input %d\n", readed, handle->net_total, input);
    }

    // 每次读取完数据需要清空输入缓冲区
    evbuffer_drain(handle->inputbuf, evbuffer_get_length(handle->inputbuf));
}

void error_cb(struct bufferevent* bev, short error, void* ctx)
{
    if (error & BEV_EVENT_EOF)
    {
        // 连接已关闭
        printf("Connection closed.\n");
    }
    else if (error & BEV_EVENT_ERROR)
    {
        // 发生错误
        printf("Error occurred..\n");
    }
    printf("Error occurred.\n");
    // 关闭 bufferevent
    // bufferevent_free(bev);
}

void timer_callback(evutil_socket_t fd, short events, void *arg) {
    Handle *handle = (Handle *)arg;
    ikcp_update(handle->kcp, (IUINT32)iclock());

    int peeksize = ikcp_peeksize(handle->kcp);
    if (peeksize > 0) {
        // 从KCP中接收数据
        char recvBuffer[BUFFER_SIZE];
        int recvlen = ikcp_recv(handle->kcp, recvBuffer, BUFFER_SIZE);
        if (recvlen > 0) {
            handle->total += recvlen;
            // 处理接收到的数据，这里将数据写入文件
            //    fwrite(recvBuffer, 1, dataLen, file);
            //    fflush(file);
            //    peeksize -= recvlen;
        }
        fprintf(stderr, "kcp peak %d recv %d total %d net %d\n", peeksize, recvlen, handle->total, handle->net_total);
    }
    fprintf(stderr, "write callback left %lu \n",  evbuffer_get_length(handle->outputbuf));
}

int main() {
    // 创建文件
    FILE *file = fopen(FILENAME, "wb");
    if (!file) {
        perror("Failed to open file");
        return 1;
    }

    // 创建UDP套接字
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    evutil_make_socket_nonblocking(sockfd);
    
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(12345);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    // 直接使用bind系统调用绑定
    int ret = bind(sockfd, (struct sockaddr*)&addr, sizeof(addr));
    fprintf(stderr, "bind %d\n", ret);

    // 创建libevent上下文
    struct event_base *base = event_base_new();
    handle.base = base;

    // 创建bufferevent
    handle.bev = bufferevent_socket_new(base, sockfd, BEV_OPT_CLOSE_ON_FREE);
    handle.outputbuf = bufferevent_get_output(handle.bev);
    handle.inputbuf  = bufferevent_get_input(handle.bev);
    // 设置回调函数
    bufferevent_setcb(handle.bev, read_cb, write_cb, NULL, &handle);
    bufferevent_setwatermark(handle.bev, EV_WRITE, 0, 10);
    
    struct event *timer_event = event_new(base, -1, EV_PERSIST, timer_callback, &handle);
    struct timeval timer_interval = {0, 10000};
    event_add(timer_event, &timer_interval);

    // 创建KCP实例
    handle.kcp = ikcp_create(0x11223344, (void *)&handle);
    handle.kcp->output = kcp_output;

    // 设置KCP参数
    ikcp_wndsize(handle.kcp, 32, 32);
    ikcp_nodelay(handle.kcp, 1, 10, 2, 1);

    bufferevent_enable(handle.bev, EV_READ | EV_WRITE); 
    event_base_dispatch(base);

    // 关闭KCP和libevent
    // ikcp_release(kcp);
    event_base_free(base);

    // 关闭文件和套接字
    fclose(file);
    close(sockfd);

    return 0;
}

